import java.util.Random;
/*


 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author luisa
 */
public class Insercion {
    
    public static void generarYOrdenarBurbuja(int[] numeros, int n) {
        // Caso base: si n es 1, el arreglo está ordenado
        if (n <= 1) {
            return;
        }

        // Recorrer el arreglo comparando elementos adyacentes
        for (int i = 0; i < n - 1; i++) {
            if (numeros[i] > numeros[i + 1]) {
                // Intercambiar elementos si están en el orden incorrecto
                int temp = numeros[i];
                numeros[i] = numeros[i + 1];
                numeros[i + 1] = temp;
            }
        }

        // Llamada recursiva para la siguiente pasada
        generarYOrdenarBurbuja(numeros, n - 1);
    }

    public static void main(String[] args) {
        int[] numeros = new int[10];
        Random random = new Random();

        // Generar los números aleatorios
        for (int i = 0; i < numeros.length; i++) {
            numeros[i] = random.nextInt(50) + 1;
        }

        // Ordenar los números usando el método de la burbuja recursivo
        generarYOrdenarBurbuja(numeros, numeros.length);

        // Imprimir los números ordenados
        for (int numero : numeros) {
            System.out.print(numero + " ");
        }
    }
}
